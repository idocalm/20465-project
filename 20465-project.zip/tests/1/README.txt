Test #1 HAS errors. 
Each error is described in a comment inside the .as file 
In addition, see the pictures in this folder for the exact errors reported.