Test #2 is a valid assembly program, 
files listed as expected.--- are the correct output files for the code 
test.am, test.ent, test.ext, test.ob are the output files of the program. 

This file doesn't have a special pdf file because this test is taken from the booklet. 