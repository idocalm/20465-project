This test file covers some edge cases related to code lines.
See expected.am for the expected output.

Obviously no .ext, .ent, .ob are created because there are many errors during the first pass.
See Errors.png image for the exact errors.

