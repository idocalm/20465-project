This test file is primarly for macro related problems.

You can see Errors.png for the exact errors, in addition to the comments 
in the .as file 

